﻿var CountryConfig = (function () {
    /* Internal Methods */
    function getCountryCode(CountryCode){
        Shop = Shop || {};
        CountryCode = CountryCode || Shop.CountryCode;
        return CountryCode? CountryCode.toUpperCase() : '';
    }
    function _IsLocaleInArray(Locales, CountryCode) {
        CountryCode = getCountryCode(CountryCode);
        return (Locales.indexOf(CountryCode) !== -1)
    }
    /* Methods to Expose*/
    function _IsProductCombosEnabled(CountryCode) {
        return !_IsLocaleInArray(['DE'], CountryCode);
    }
    function _IsLoyaltyEnabled(CountryCode) {
        return _IsLocaleInArray(['US', 'PR', 'KR'], CountryCode);
    }
    function _IsShowRelatedEnabled(CountryCode) {
        return !_IsLocaleInArray(['RU'], CountryCode);
    }
    function _IsBoughtTogetherEnabled(CountryCode) {
        return !_IsLocaleInArray(['RU'], CountryCode);
    }
    function _IsLogged(CountryCode) {
        return _IsLocaleInArray(['US', 'PR', 'KR'], CountryCode);
    }
    function _AnonymousCartEnabled(CountryCode) {
        return _IsLocaleInArray(['US','GB','DE', 'NL', 'IT', 'AT', 'NO', 'CH','MX','ES','FR','BE', 'CA', 'JP', 'KR', 'TR', 'AU'], CountryCode);
    }
    function _IsActivityPointsEnabled(CountryCode) {
        return _IsLocaleInArray(['US', 'PR'], CountryCode);
    }
    /*Public API*/
    return {
        IsProductCombosEnabled: _IsProductCombosEnabled,
        IsLoyaltyEnabled: _IsLoyaltyEnabled,
        IsShowRelatedEnabled: _IsShowRelatedEnabled,
        IsBoughtTogetherEnabled: _IsBoughtTogetherEnabled,
        IsLogged: _IsLogged,
        AnonymousCartEnabled: _AnonymousCartEnabled,
        IsActivityPointsEnabled: _IsActivityPointsEnabled
    }
})();
